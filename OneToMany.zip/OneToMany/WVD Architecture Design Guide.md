# WVD アーキテクチャー デザイン ガイド (Powered By FTA)
このドキュメントは FTA (FastTrack for Azure) のメンバーによって管理されているものであり、WVD (Windows Virtual Desktop) 環境を新たに作成されようとしている方に対して WVD に対する理解を深め、多様なビジネス要件を満たすために WVD や Azure が提供している機能やそのつながりを理解してもらうために作成されたものです。

内容は FTA のメンバーによって適宜更新されますが、内容の正しさを保証するものではありません。WVD に関する最新の情報や WVD の正確な仕様を確認する場合は必ず[公式ドキュメント](https://docs.microsoft.com/ja-jp/azure/virtual-desktop/overview)を参照してください。

FTA (FastTrack for Azure) 組織については[こちら](https://azure.microsoft.com/ja-jp/programs/azure-fasttrack/)を参照ください。

## 1. 必要条件
WVD は Microsoft Azure 上で動作する仮想デスクトップを提供するサービスです。WVD を動作させるには最低限以下のコンポーネントが必要です。

- Azure サブスクリプション
- Azure AD テナント
- Windows Active Directory 環境（Azure Active Directory Domain Service でも可）
- 適切なライセンス（https://azure.microsoft.com/ja-jp/pricing/details/virtual-desktop）

WVD は以下図のイメージでAzureサブスクリプションのvNet内に展開したVMにWVD Agentをインストールし、VDI として利用します。WVD を展開する際に必要となるコンポーネントについてご説明します。

![overalldesign](images/overalldesign1.png)

1．Active Directory Domain Service (ADDS)
- WVD VM が参加するドメインコントローラー
-  ADDS の選択肢は複数存在し、お客様のご要件に応じて柔軟に選択できます。
    - オンプレミスに存在する既存 AD
        - AzureとオンプレミスDCを専用線 / VPNで接続し、WVDで利用するAzure上のVMをオンプレミスのADに参加
    - Azure IaaS上に新規構築
    - Azure の AD サービス (Azure Active Directory Domain Service) を利用

2. Azure AD Connect
	- AD/DNSからUPNをAzure ADへ同期
	- 既存でAzure AD Connectを利用している場合は注意が必要
※AADCがサポートするトポロジ
	- Azure AD ConnectはWindows Serverに対してソフトウェアをインストールし、構成する
Azure AD ConnectでADからAzure ADへ同期する設定を実施する際には以下留意点が存在
・同期設定時、Azure ADのグローバル管理者権限をもったアカウントが必要
・同期設定時、ADへのエンタープライズ権限をもったアカウントが必要
・グローバル管理者は他のAzure ADからゲスト招待されているユーザーは不可

3. Azure AD
	- WVDにアクセスするユーザーはAzure ADの認証基盤でログイン認証を実施
	- 複数のAzure ADテナントが存在する場合は注意が必要
※構築の際に問題になることが多いPoint
	- WVDにアクセスする際にAADの多要素認証機能の利用が可能
・Azure AD Premier P1ライセンス以上が必要
	- AADにはWVDにアクセスするユーザーがADDSから同期されている
・別のAzure ADから招待されたゲストユーザー、AzureAD B2B はWVDへのアクセスが不可

![adtenant](images/adtenant.png)

4. Azure サブスクリプション
	- WVDのマシンを展開するAzureサブスクリプション
- WVDにアクセスするユーザーが存在するAzure ADテナントに紐づくAzureサブスクリプションが必要


## 2. コンセプト



## 3. ネットワーク要件


## 4. デザイン パターン
ここでは一般的なエンタープライズ環境で既存のオンプレミス Active Directory 環境を活用しつつ、WVD を利用する場合によく採用される構成を紹介します。

<!--
<img src="https://github.com/Azure/fta-japan/blob/main/OneToMany/images/NetworkDesign1.png" width=50%>
-->

### インターネット接続分離パターン
---

***
![networkdesign1](images/NetworkDesign1.png)
***

赤枠で囲っている仮想ネットワークに WVD のホストプールを配置しています。ホストプールが必要とする通信は大きく分けて2種類あり、一つは接続元のクライアントと WVD コントロールプレーンを経由した画面転送に関するもの。もう一つはホストプール接続後の Office 365 の利用や通常の Web ブラウジング等の通信で利用するものです。
多くのエンタープライズ環境では自社内にプロキシサーバーを設置しており、社内からインターネットへのアクセスにはプロキシサーバーを要件としている場合が多々あります。



1. 


## 5. ログとモニタリング
## 6. 各種ツール

<!---

7.	WVD  ID Security (Optional) 
  i.	Azure AD Conditional Access (Azure AD Premium) 
  ii.	Intune 
  iii.	MDATP
8.	WVD Image management (Optional) 
  i.	Capture images 
  ii.	Shared Image Gallery 
9.	WVD Misc (Optional)
  i.	vCPU Quota
  ii.	Scale limit (https://docs.microsoft.com/ja-jp/azure/architecture/example-scenario/wvd/windows-virtual-desktop)

-->
